"""This example turns on the little red LED."""
from adafruit_circuitplayground.express import cpx

while True:
    cpx.red_led = True
